# CommandCenter 3.0 — Simplified Spec

**What it is**: A strategic intelligence tool that helps you discover paths to 100M ARR.

**What it is not**: A dev tool (that's AutoClaude's job).

---

## The Loop

Everything serves this:

```
DISCOVER → VALIDATE → IMPROVE
   ↑                      │
   └──────────────────────┘
```

- **DISCOVER**: Explore problem spaces, find opportunities, generate ideas
- **VALIDATE**: Test hypotheses against reality (not AI consensus)
- **IMPROVE**: Refine based on what you learned, repeat

---

## Three Tabs

### 1. Ideas Tab (`/`)

The entry point. Three buttons:

| Button | What Happens |
|--------|--------------|
| **"I want to explore..."** | Opens text input → Wander agent explores the space → Returns nascent ideas to canvas |
| **"I have an idea"** | Opens form → Captures idea → Adds to canvas as Idea node |
| **"I need something built"** | Goes to Build tab (AutoClaude) |

### 2. Canvas Tab (`/canvas`) — VISLZR

A mind map where ideas crystallize.

**Node Types** (4 total, not 10):

| Type | Visual | Meaning |
|------|--------|---------|
| **Resonance** | Soft glow, diffuse edges | Nascent, unexplored |
| **Idea** | Solid circle | Captured, needs validation |
| **Hypothesis** | Diamond | Testable claim extracted from idea |
| **Task** | Square | Ready to build |

**Crystallization Flow**:
```
Resonance → Idea → Hypothesis → Task
  (soft)   (solid)  (diamond)   (square)
```

**Action Ring** (right-click or tap node):

| Node Type | Actions |
|-----------|---------|
| Resonance | Explore more, Capture as Idea, Delete |
| Idea | Extract hypotheses, Validate, Archive |
| Hypothesis | Validate, Convert to Task, Reject |
| Task | Send to Build, Edit, Archive |

**Canvas Interactions**:
- Drag to pan
- Scroll to zoom
- Click node to select
- Double-click to edit
- Drag between nodes to connect
- `Cmd+K` for command palette (search/create)

### 3. Build Tab (`/build`)

Embeds AutoClaude. When a Task node is "Sent to Build":
1. Task description becomes the spec
2. AutoClaude handles: planning, implementation, QA
3. Results link back to the Task node

**Implementation**: iframe to AutoClaude or deep-link to standalone app.

---

## Data Model

```sql
-- That's it. Three tables.

CREATE TABLE projects (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  goal TEXT,  -- e.g., "100M ARR by 2027"
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE ideas (
  id TEXT PRIMARY KEY,
  project_id TEXT REFERENCES projects(id),
  title TEXT NOT NULL,
  description TEXT,
  status TEXT DEFAULT 'resonance',  -- resonance | idea | hypothesis | task
  confidence REAL,  -- 0.0-1.0, set after validation
  parent_id TEXT REFERENCES ideas(id),  -- for crystallization lineage
  position_x REAL,  -- canvas position
  position_y REAL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE connections (
  id TEXT PRIMARY KEY,
  source_id TEXT REFERENCES ideas(id),
  target_id TEXT REFERENCES ideas(id),
  label TEXT,  -- optional edge label
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## Strategic Intelligence

Three prompts. No complex agents, no multi-model validation, no RLM.

### 1. Wander (Explore)

```python
async def wander(context: str, goal: str) -> list[dict]:
    """
    Explores a problem space, returns nascent ideas.
    
    Returns: [{title, description, why_relevant}]
    """
    prompt = f"""You are a strategic advisor helping identify paths to: {goal}

The user wants to explore: {context}

Generate 3-5 nascent ideas worth investigating. For each:
- Title: concise name
- Description: 2-3 sentences on what this is
- Why relevant: how it connects to the goal

Be creative but grounded. These are starting points, not solutions.

Return as JSON array."""

    response = await claude(prompt)
    return parse_json(response)
```

### 2. Validate (Test)

```python
async def validate(hypothesis: str, context: str) -> dict:
    """
    Tests a hypothesis, returns confidence + reasoning.
    
    Returns: {confidence: 0.0-1.0, reasoning: str, risks: [str], next_steps: [str]}
    """
    prompt = f"""Evaluate this hypothesis:

"{hypothesis}"

Context: {context}

Be rigorous. Consider:
1. What evidence supports this?
2. What evidence contradicts this?
3. What's unknown that matters?
4. What could go wrong?

Return JSON:
{{
  "confidence": 0.0-1.0,
  "reasoning": "your assessment",
  "risks": ["risk1", "risk2"],
  "next_steps": ["what to do to increase confidence"]
}}

Do NOT be agreeable. If it's a bad idea, say so."""

    response = await claude(prompt)
    return parse_json(response)
```

### 3. Plan (Strategize)

```python
async def plan(validated_idea: str, goal: str, constraints: str) -> list[dict]:
    """
    Converts validated idea into actionable path.
    
    Returns: [{action, why, effort, dependencies}]
    """
    prompt = f"""Create an action plan.

Goal: {goal}
Validated idea: {validated_idea}
Constraints: {constraints}

Generate 3-7 concrete next actions. For each:
- Action: specific, measurable step
- Why: how it advances the goal
- Effort: low/medium/high
- Dependencies: what needs to happen first

Order by priority. First action should be doable this week.

Return as JSON array."""

    response = await claude(prompt)
    return parse_json(response)
```

---

## API Routes

```
POST   /api/projects              Create project
GET    /api/projects              List projects
GET    /api/projects/:id          Get project

POST   /api/ideas                 Create idea
GET    /api/ideas?project_id=X    List ideas for project
GET    /api/ideas/:id             Get idea
PATCH  /api/ideas/:id             Update idea (status, position, etc.)
DELETE /api/ideas/:id             Delete idea

POST   /api/connections           Create connection
DELETE /api/connections/:id       Delete connection

POST   /api/wander                Explore (returns ideas)
POST   /api/validate              Validate hypothesis
POST   /api/plan                  Generate action plan
```

---

## Tech Stack

| Layer | Choice | Why |
|-------|--------|-----|
| Frontend | React + React Flow | Canvas library that works |
| Backend | FastAPI | You know it, it's fast |
| Database | SQLite | Simple, no setup, good enough |
| AI | Claude API direct | No wrappers, no complexity |

---

## Build Order (Today)

### Hour 1-2: Backend
1. FastAPI app with SQLite
2. Projects + Ideas + Connections CRUD
3. Three strategic prompts (wander, validate, plan)

### Hour 3-4: Frontend - Ideas Tab
1. Project selector
2. Three entry buttons
3. Simple forms for idea capture

### Hour 5-6: Frontend - Canvas
1. React Flow setup
2. Four node types with custom styling
3. Action ring (context menu)
4. Basic interactions (drag, connect, edit)

### Hour 7: Integration
1. Ideas Tab → Canvas flow
2. Wander results → Canvas nodes
3. Validate → Updates confidence on node

### Hour 8: Build Tab
1. Iframe or link to AutoClaude
2. "Send to Build" action on Task nodes

---

## What's NOT in V1

- Revenue dashboard (later)
- Multi-user (later)
- Memory/history beyond simple DB (later)
- FedRAMP compliance (much later)
- Billing (when you have customers)
- Complex validation (AI Arena, multi-model)
- RLM, 6-layer memory, tiered visual memory
- Any "machinery" the user would see

---

## Success Criteria

1. ✅ Can capture an idea in < 10 seconds
2. ✅ Can explore a space and get useful starting points
3. ✅ Can validate a hypothesis and get honest feedback
4. ✅ Can see ideas crystallize on canvas (resonance → task)
5. ✅ Can send a task to AutoClaude for building
6. ✅ **User never sees "the machinery"** — just ideas and results

---

## The Philosophy

> "It's not a tool you use. It's a space you inhabit."

But first, it has to work. Elegance comes from simplicity, not from features.

---

*Total: ~200 lines of spec. ~8 hours to build. Ship it.*
